// ========================================
// SERENITY WOOD - Rituals Page JavaScript
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
    initFilters();
    renderRituals();
});

// Current filter
let currentFilter = 'all';

// ========================================
// Initialize Filters
// ========================================
function initFilters() {
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Update active state
            document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Update filter
            currentFilter = this.dataset.filter;
            renderRituals();
        });
    });
}

// ========================================
// Render Rituals
// ========================================
function renderRituals() {
    const container = document.getElementById('rituals-grid');
    if (!container || typeof rituals === 'undefined') return;
    
    // Filter rituals
    const filteredRituals = currentFilter === 'all' 
        ? rituals 
        : rituals.filter(r => r.category === currentFilter);
    
    container.innerHTML = filteredRituals.map(ritual => `
        <div class="ritual-card" data-category="${ritual.category}">
            <div class="ritual-card-image">
                <span>▶</span>
                <div class="ritual-play-btn">▶</div>
            </div>
            <div class="ritual-card-content">
                <span class="ritual-duration">${ritual.duration}</span>
                <h3>${ritual.title}</h3>
                <p>${ritual.description}</p>
                <a href="#" class="ritual-card-link" onclick="openRitualModal(${ritual.id}); return false;">
                    Start Practice →
                </a>
            </div>
        </div>
    `).join('');
}

// ========================================
// Open Ritual Modal
// ========================================
function openRitualModal(ritualId) {
    if (typeof rituals === 'undefined') return;
    
    const ritual = rituals.find(r => r.id === ritualId);
    if (!ritual) return;
    
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'ritual-modal';
    modal.innerHTML = `
        <div class="ritual-modal-overlay" onclick="closeRitualModal()"></div>
        <div class="ritual-modal-content">
            <button class="ritual-modal-close" onclick="closeRitualModal()">✕</button>
            <div class="ritual-modal-video">
                <div class="video-placeholder">
                    <span>▶</span>
                    <p>Video Player</p>
                </div>
            </div>
            <div class="ritual-modal-info">
                <span class="ritual-duration">${ritual.duration}</span>
                <h2>${ritual.title}</h2>
                <p>${ritual.description}</p>
                <div class="ritual-modal-tips">
                    <h4>Tips for This Practice:</h4>
                    <ul>
                        <li>Find a quiet, comfortable space</li>
                        <li>Light your agarwood incense 5 minutes before starting</li>
                        <li>Keep a glass of water nearby</li>
                        <li>Wear comfortable clothing</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Add modal styles
    if (!document.getElementById('ritual-modal-styles')) {
        const styles = document.createElement('style');
        styles.id = 'ritual-modal-styles';
        styles.textContent = `
            .ritual-modal {
                position: fixed;
                inset: 0;
                z-index: 1000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 2rem;
            }
            
            .ritual-modal-overlay {
                position: absolute;
                inset: 0;
                background-color: rgba(0,0,0,0.8);
            }
            
            .ritual-modal-content {
                position: relative;
                background-color: var(--color-white);
                width: 100%;
                max-width: 900px;
                max-height: 90vh;
                overflow-y: auto;
                border-radius: 8px;
                z-index: 1;
            }
            
            .ritual-modal-close {
                position: absolute;
                top: 1rem;
                right: 1rem;
                width: 40px;
                height: 40px;
                background-color: rgba(255,255,255,0.9);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.25rem;
                z-index: 10;
                transition: background-color var(--transition-fast);
            }
            
            .ritual-modal-close:hover {
                background-color: var(--color-white);
            }
            
            .ritual-modal-video {
                aspect-ratio: 16/9;
                background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-light) 100%);
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .video-placeholder {
                text-align: center;
                color: rgba(255,255,255,0.7);
            }
            
            .video-placeholder span {
                font-size: 4rem;
                display: block;
                margin-bottom: 1rem;
            }
            
            .ritual-modal-info {
                padding: 2rem;
            }
            
            .ritual-modal-info .ritual-duration {
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: var(--color-secondary);
            }
            
            .ritual-modal-info h2 {
                margin: 0.5rem 0 1rem;
                color: var(--color-primary);
            }
            
            .ritual-modal-info p {
                color: var(--color-text-light);
                line-height: 1.7;
                margin-bottom: 1.5rem;
            }
            
            .ritual-modal-tips {
                background-color: var(--color-bg);
                padding: 1.5rem;
                border-radius: 4px;
            }
            
            .ritual-modal-tips h4 {
                margin-bottom: 1rem;
                color: var(--color-primary);
            }
            
            .ritual-modal-tips ul {
                list-style: disc;
                padding-left: 1.25rem;
            }
            
            .ritual-modal-tips li {
                color: var(--color-text-light);
                margin-bottom: 0.5rem;
                font-size: 0.875rem;
            }
            
            @media (max-width: 768px) {
                .ritual-modal {
                    padding: 0;
                }
                
                .ritual-modal-content {
                    max-height: 100vh;
                    border-radius: 0;
                }
            }
        `;
        document.head.appendChild(styles);
    }
}

// ========================================
// Close Ritual Modal
// ========================================
function closeRitualModal() {
    const modal = document.querySelector('.ritual-modal');
    if (modal) {
        modal.remove();
        document.body.style.overflow = '';
    }
}

// ========================================
// Mobile Menu
// ========================================
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-menu-close');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
}
