// ========================================
// SERENITY WOOD - Main JavaScript
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all modules
    initMobileMenu();
    initNewsletterForm();
    loadFeaturedProducts();
    initScrollAnimations();
});

// ========================================
// Mobile Menu
// ========================================
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-menu-close');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
}

// ========================================
// Newsletter Form
// ========================================
function initNewsletterForm() {
    const form = document.getElementById('newsletter-form');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            // Show success message
            alert('Thank you for subscribing! You\'ll receive our latest rituals and stories soon.');
            this.reset();
        });
    }
}

// ========================================
// Load Featured Products
// ========================================
function loadFeaturedProducts() {
    const container = document.getElementById('featured-products');
    
    if (container && typeof products !== 'undefined') {
        // Get first 4 products as featured
        const featuredProducts = products.slice(0, 4);
        
        container.innerHTML = featuredProducts.map(product => `
            <div class="product-card">
                <div class="product-image">
                    <div class="product-placeholder">${product.name}</div>
                    ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
                    <div class="product-quick-add">
                        <button onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p class="product-price">
                        ${product.originalPrice ? `<span class="original">$${product.originalPrice.toFixed(2)}</span>` : ''}
                        $${product.price.toFixed(2)}
                    </p>
                </div>
            </div>
        `).join('');
    }
}

// ========================================
// Add to Cart
// ========================================
function addToCart(productId) {
    if (typeof products !== 'undefined' && typeof cart !== 'undefined') {
        const product = products.find(p => p.id === productId);
        if (product) {
            cart.addItem(product);
        }
    }
}

// ========================================
// Scroll Animations
// ========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.pillar-card, .product-card, .story-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Add animation class styles
const style = document.createElement('style');
style.textContent = `
    .animate-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
    }
`;
document.head.appendChild(style);

// ========================================
// Smooth Scroll for Anchor Links
// ========================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href');
        if (targetId !== '#') {
            e.preventDefault();
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// ========================================
// Header Scroll Effect
// ========================================
let lastScroll = 0;
const header = document.querySelector('.main-header');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        header?.classList.add('scrolled');
    } else {
        header?.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
});

// Add scrolled header styles
const headerStyle = document.createElement('style');
headerStyle.textContent = `
    .main-header.scrolled {
        box-shadow: 0 2px 20px rgba(0,0,0,0.1);
    }
`;
document.head.appendChild(headerStyle);
