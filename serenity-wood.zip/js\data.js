// ========================================
// SERENITY WOOD - Product Data
// ========================================

const products = [
    {
        id: 1,
        name: "Morning Meditation Set",
        category: "meditation",
        grade: "everyday",
        type: "incense",
        price: 68.00,
        originalPrice: null,
        badge: "Bestseller",
        description: "Begin your day with intention. This carefully curated set includes 30 sticks of our signature Vietnamese agarwood incense, a handcrafted ceramic holder, and a guided meditation audio track.",
        scentProfile: "Warm, woody base notes with hints of honey and vanilla. Perfect for creating a calm, focused atmosphere.",
        burnTime: "45 minutes per stick",
        origin: "Vietnam",
        images: ["product-1"]
    },
    {
        id: 2,
        name: "Deep Sleep Incense",
        category: "sleep",
        grade: "everyday",
        type: "incense",
        price: 45.00,
        originalPrice: null,
        badge: null,
        description: "Unwind and prepare for restful sleep with this calming blend. Specially formulated to promote relaxation and ease the transition into sleep.",
        scentProfile: "Soft, soothing notes of sandalwood and agarwood with a touch of lavender.",
        burnTime: "60 minutes per stick",
        origin: "Hainan, China",
        images: ["product-2"]
    },
    {
        id: 3,
        name: "Ceremonial Grade Chips",
        category: "meditation",
        grade: "connoisseur",
        type: "chips",
        price: 128.00,
        originalPrice: 158.00,
        badge: "Limited",
        description: "Premium agarwood chips for the discerning practitioner. Each piece has been aged for over 15 years, developing a rich, complex aroma profile.",
        scentProfile: "Deep, resinous base with sweet, floral top notes and a lingering musky finish.",
        burnTime: "Variable - use on electric or charcoal burner",
        origin: "Vietnam",
        images: ["product-3"]
    },
    {
        id: 4,
        name: "Zen Incense Holder",
        category: "home",
        grade: "everyday",
        type: "accessory",
        price: 85.00,
        originalPrice: null,
        badge: null,
        description: "Handcrafted ceramic incense holder with a minimalist design. The ash-catching basin ensures clean, safe burning.",
        scentProfile: null,
        burnTime: null,
        origin: "Japan",
        images: ["product-4"]
    },
    {
        id: 5,
        name: "Hainan Premium Oud",
        category: "meditation",
        grade: "rare",
        type: "oil",
        price: 298.00,
        originalPrice: null,
        badge: "Rare",
        description: "Pure oud oil from wild Hainan agarwood. This exceptional oil captures the essence of one of the world's most prized aromatics.",
        scentProfile: "Intensely rich and complex with sweet, woody, and slightly medicinal notes.",
        burnTime: "N/A - Apply sparingly to pulse points",
        origin: "Hainan, China",
        images: ["product-5"]
    },
    {
        id: 6,
        name: "Beginner's Ritual Kit",
        category: "meditation",
        grade: "everyday",
        type: "set",
        price: 95.00,
        originalPrice: 120.00,
        badge: "Value",
        description: "Everything you need to begin your agarwood journey. Includes three varieties of incense, a holder, and our comprehensive guide to mindful burning.",
        scentProfile: "Variety pack - experience different aroma profiles",
        burnTime: "90+ sticks total",
        origin: "Mixed",
        images: ["product-6"]
    },
    {
        id: 7,
        name: "Evening Wind Down",
        category: "sleep",
        grade: "everyday",
        type: "incense",
        price: 52.00,
        originalPrice: null,
        badge: "New",
        description: "Release the tension of the day with this grounding blend. Designed to help you transition from work mode to rest mode.",
        scentProfile: "Earthy, grounding notes with subtle sweetness.",
        burnTime: "50 minutes per stick",
        origin: "Indonesia",
        images: ["product-7"]
    },
    {
        id: 8,
        name: "Sacred Space Spray",
        category: "home",
        grade: "everyday",
        type: "spray",
        price: 38.00,
        originalPrice: null,
        badge: null,
        description: "Instantly transform any space with this room spray featuring pure agarwood essence. Perfect for travel or when burning incense isn't practical.",
        scentProfile: "Light, refreshing agarwood with citrus top notes.",
        burnTime: "N/A - Spray as needed",
        origin: "Vietnam",
        images: ["product-8"]
    }
];

// Rituals data
const rituals = [
    {
        id: 1,
        title: "Morning Intention Setting",
        duration: "10 min",
        category: "meditation",
        description: "A 10-minute guided practice to start your day with clarity and purpose",
        image: "ritual-1"
    },
    {
        id: 2,
        title: "Deep Sleep Preparation",
        duration: "15 min",
        category: "sleep",
        description: "Wind down with this evening ritual designed to prepare mind and body for rest",
        image: "ritual-2"
    },
    {
        id: 3,
        title: "Mindful Breathing",
        duration: "8 min",
        category: "meditation",
        description: "Learn the art of conscious breathing enhanced by the presence of agarwood",
        image: "ritual-3"
    },
    {
        id: 4,
        title: "Home Cleansing Ritual",
        duration: "12 min",
        category: "home",
        description: "Clear and refresh your living space with this traditional practice",
        image: "ritual-4"
    },
    {
        id: 5,
        title: "Yoga & Incense Flow",
        duration: "25 min",
        category: "meditation",
        description: "A gentle yoga sequence designed to complement your agarwood practice",
        image: "ritual-5"
    },
    {
        id: 6,
        title: "The Art of Listening",
        duration: "20 min",
        category: "meditation",
        description: "Develop deeper presence through this sound and scent meditation",
        image: "ritual-6"
    }
];

// Stories data
const stories = [
    {
        id: 1,
        title: "The Wounded Tree: How Agarwood is Born",
        category: "Education",
        excerpt: "Discover the fascinating journey from tree injury to precious resin...",
        image: "story-1"
    },
    {
        id: 2,
        title: "Vietnam's Hidden Agarwood Forests",
        category: "Origin",
        excerpt: "A journey to the source of the world's finest oud...",
        image: "story-2"
    },
    {
        id: 3,
        title: "The Science of Scent & Memory",
        category: "Wellness",
        excerpt: "Why agarwood has been used for meditation for millennia...",
        image: "story-3"
    },
    {
        id: 4,
        title: "From Tree to Temple: A History",
        category: "History",
        excerpt: "Tracing the sacred use of agarwood through the ages...",
        image: "story-4"
    },
    {
        id: 5,
        title: "Sustainable Harvesting Practices",
        category: "Sustainability",
        excerpt: "How we're protecting wild populations while meeting demand...",
        image: "story-5"
    },
    {
        id: 6,
        title: "The Art of Incense Making",
        category: "Craft",
        excerpt: "Inside our workshop where tradition meets precision...",
        image: "story-6"
    }
];

// Filter options
const filterOptions = {
    category: [
        { id: "meditation", label: "Meditation & Mindfulness" },
        { id: "sleep", label: "Sleep & Relaxation" },
        { id: "home", label: "Home Sanctuary" },
        { id: "gift", label: "Gifting" }
    ],
    grade: [
        { id: "everyday", label: "Everyday Wellness" },
        { id: "connoisseur", label: "Connoisseur" },
        { id: "rare", label: "Rare & Aged" }
    ],
    type: [
        { id: "incense", label: "Incense Sticks" },
        { id: "chips", label: "Loose Chips" },
        { id: "oil", label: "Oud Oil" },
        { id: "accessory", label: "Accessories" },
        { id: "set", label: "Gift Sets" },
        { id: "spray", label: "Room Spray" }
    ]
};
