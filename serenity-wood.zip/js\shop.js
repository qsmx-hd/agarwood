// ========================================
// SERENITY WOOD - Shop Page JavaScript
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    initFilters();
    initMobileMenu();
    renderProducts();
    updateProductCount();
});

// Current filter state
let currentFilters = {
    category: [],
    grade: [],
    type: [],
    price: []
};

let currentSort = 'featured';

// ========================================
// Initialize Filters
// ========================================
function initFilters() {
    // Populate filter options
    populateFilterOptions();
    
    // Bind filter events
    bindFilterEvents();
    
    // Bind sort event
    document.getElementById('sort-select')?.addEventListener('change', function() {
        currentSort = this.value;
        renderProducts();
    });
    
    // Mobile filter toggle
    document.querySelector('.mobile-filter-toggle')?.addEventListener('click', function() {
        document.getElementById('filter-groups').classList.toggle('active');
    });
    
    // Clear filters
    document.getElementById('clear-filters')?.addEventListener('click', clearAllFilters);
    document.getElementById('reset-filters')?.addEventListener('click', clearAllFilters);
}

// ========================================
// Populate Filter Options
// ========================================
function populateFilterOptions() {
    if (typeof filterOptions === 'undefined') return;
    
    // Category filters
    const categoryContainer = document.getElementById('category-filters');
    if (categoryContainer) {
        categoryContainer.innerHTML = filterOptions.category.map(opt => `
            <label class="filter-option">
                <input type="checkbox" name="category" value="${opt.id}">
                <span>${opt.label}</span>
            </label>
        `).join('');
    }
    
    // Grade filters
    const gradeContainer = document.getElementById('grade-filters');
    if (gradeContainer) {
        gradeContainer.innerHTML = filterOptions.grade.map(opt => `
            <label class="filter-option">
                <input type="checkbox" name="grade" value="${opt.id}">
                <span>${opt.label}</span>
            </label>
        `).join('');
    }
    
    // Type filters
    const typeContainer = document.getElementById('type-filters');
    if (typeContainer) {
        typeContainer.innerHTML = filterOptions.type.map(opt => `
            <label class="filter-option">
                <input type="checkbox" name="type" value="${opt.id}">
                <span>${opt.label}</span>
            </label>
        `).join('');
    }
}

// ========================================
// Bind Filter Events
// ========================================
function bindFilterEvents() {
    document.querySelectorAll('.filter-option input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const filterType = this.name;
            const filterValue = this.value;
            
            if (this.checked) {
                currentFilters[filterType].push(filterValue);
            } else {
                currentFilters[filterType] = currentFilters[filterType].filter(v => v !== filterValue);
            }
            
            renderProducts();
            updateProductCount();
        });
    });
}

// ========================================
// Clear All Filters
// ========================================
function clearAllFilters() {
    currentFilters = {
        category: [],
        grade: [],
        type: [],
        price: []
    };
    
    // Uncheck all checkboxes
    document.querySelectorAll('.filter-option input[type="checkbox"]').forEach(cb => {
        cb.checked = false;
    });
    
    renderProducts();
    updateProductCount();
}

// ========================================
// Filter Products
// ========================================
function filterProducts() {
    if (typeof products === 'undefined') return [];
    
    return products.filter(product => {
        // Category filter
        if (currentFilters.category.length > 0 && !currentFilters.category.includes(product.category)) {
            return false;
        }
        
        // Grade filter
        if (currentFilters.grade.length > 0 && !currentFilters.grade.includes(product.grade)) {
            return false;
        }
        
        // Type filter
        if (currentFilters.type.length > 0 && !currentFilters.type.includes(product.type)) {
            return false;
        }
        
        // Price filter
        if (currentFilters.price.length > 0) {
            const priceMatch = currentFilters.price.some(range => {
                if (range === '0-50') return product.price < 50;
                if (range === '50-100') return product.price >= 50 && product.price < 100;
                if (range === '100-200') return product.price >= 100 && product.price < 200;
                if (range === '200+') return product.price >= 200;
                return false;
            });
            if (!priceMatch) return false;
        }
        
        return true;
    });
}

// ========================================
// Sort Products
// ========================================
function sortProducts(products) {
    const sorted = [...products];
    
    switch (currentSort) {
        case 'price-low':
            sorted.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            sorted.sort((a, b) => b.price - a.price);
            break;
        case 'name':
            sorted.sort((a, b) => a.name.localeCompare(b.name));
            break;
        default:
            // Featured - keep original order
            break;
    }
    
    return sorted;
}

// ========================================
// Render Products
// ========================================
function renderProducts() {
    const container = document.getElementById('shop-products');
    const noResults = document.getElementById('no-results');
    
    if (!container) return;
    
    let filteredProducts = filterProducts();
    filteredProducts = sortProducts(filteredProducts);
    
    if (filteredProducts.length === 0) {
        container.style.display = 'none';
        noResults.style.display = 'block';
    } else {
        container.style.display = 'grid';
        noResults.style.display = 'none';
        
        container.innerHTML = filteredProducts.map(product => `
            <div class="product-card">
                <a href="product.html?id=${product.id}" class="product-link">
                    <div class="product-image">
                        <div class="product-placeholder">${product.name}</div>
                        ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
                    </div>
                </a>
                <div class="product-info">
                    <a href="product.html?id=${product.id}">
                        <h3>${product.name}</h3>
                    </a>
                    <p class="product-price">
                        ${product.originalPrice ? `<span class="original">$${product.originalPrice.toFixed(2)}</span>` : ''}
                        $${product.price.toFixed(2)}
                    </p>
                    <button class="btn btn-primary btn-full" onclick="addToCart(${product.id})" style="margin-top: 1rem;">
                        Add to Cart
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// ========================================
// Update Product Count
// ========================================
function updateProductCount() {
    const countElement = document.getElementById('product-count');
    if (countElement) {
        const filteredProducts = filterProducts();
        countElement.textContent = filteredProducts.length;
    }
}

// ========================================
// Mobile Menu
// ========================================
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-menu-close');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
}
