// ========================================
// SERENITY WOOD - Stories Page JavaScript
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
    renderJournal();
    initScrollAnimations();
});

// ========================================
// Render Journal
// ========================================
function renderJournal() {
    const container = document.getElementById('journal-grid');
    if (!container || typeof stories === 'undefined') return;
    
    container.innerHTML = stories.map(story => `
        <article class="journal-card">
            <div class="journal-card-image">
                <span class="journal-placeholder">${story.category}</span>
            </div>
            <div class="journal-card-content">
                <span class="journal-category">${story.category}</span>
                <h3>${story.title}</h3>
                <p>${story.excerpt}</p>
                <a href="#" class="link-arrow" onclick="openStoryModal(${story.id}); return false;">Read More →</a>
            </div>
        </article>
    `).join('');
}

// ========================================
// Open Story Modal
// ========================================
function openStoryModal(storyId) {
    if (typeof stories === 'undefined') return;
    
    const story = stories.find(s => s.id === storyId);
    if (!story) return;
    
    // Create modal
    const modal = document.createElement('div');
    modal.className = 'story-modal';
    modal.innerHTML = `
        <div class="story-modal-overlay" onclick="closeStoryModal()"></div>
        <div class="story-modal-content">
            <button class="story-modal-close" onclick="closeStoryModal()">✕</button>
            <div class="story-modal-header">
                <span class="story-category">${story.category}</span>
                <h2>${story.title}</h2>
            </div>
            <div class="story-modal-body">
                <p class="story-lead">${story.excerpt}</p>
                <div class="story-content">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <h4>The Ancient Connection</h4>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                    <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
                </div>
            </div>
            <div class="story-modal-footer">
                <p>Share this story:</p>
                <div class="story-share">
                    <button class="share-btn">📘 Facebook</button>
                    <button class="share-btn">📷 Instagram</button>
                    <button class="share-btn">🔗 Copy Link</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Add modal styles
    if (!document.getElementById('story-modal-styles')) {
        const styles = document.createElement('style');
        styles.id = 'story-modal-styles';
        styles.textContent = `
            .story-modal {
                position: fixed;
                inset: 0;
                z-index: 1000;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 2rem;
            }
            
            .story-modal-overlay {
                position: absolute;
                inset: 0;
                background-color: rgba(0,0,0,0.8);
            }
            
            .story-modal-content {
                position: relative;
                background-color: var(--color-white);
                width: 100%;
                max-width: 800px;
                max-height: 90vh;
                overflow-y: auto;
                border-radius: 8px;
                z-index: 1;
            }
            
            .story-modal-close {
                position: absolute;
                top: 1rem;
                right: 1rem;
                width: 40px;
                height: 40px;
                background-color: var(--color-bg);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.25rem;
                z-index: 10;
                transition: background-color var(--transition-fast);
            }
            
            .story-modal-close:hover {
                background-color: var(--color-border);
            }
            
            .story-modal-header {
                padding: 3rem 3rem 1.5rem;
                border-bottom: 1px solid var(--color-border);
            }
            
            .story-modal-header .story-category {
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: var(--color-secondary);
            }
            
            .story-modal-header h2 {
                margin-top: 0.5rem;
                color: var(--color-primary);
            }
            
            .story-modal-body {
                padding: 2rem 3rem;
            }
            
            .story-lead {
                font-size: 1.125rem;
                color: var(--color-text-light);
                font-style: italic;
                margin-bottom: 2rem;
                padding-bottom: 2rem;
                border-bottom: 1px solid var(--color-border);
            }
            
            .story-content p {
                margin-bottom: 1.25rem;
                line-height: 1.8;
                color: var(--color-text);
            }
            
            .story-content h4 {
                margin: 2rem 0 1rem;
                color: var(--color-primary);
            }
            
            .story-modal-footer {
                padding: 1.5rem 3rem;
                background-color: var(--color-bg);
                border-top: 1px solid var(--color-border);
            }
            
            .story-modal-footer p {
                font-size: 0.875rem;
                color: var(--color-text-light);
                margin-bottom: 1rem;
            }
            
            .story-share {
                display: flex;
                gap: 0.75rem;
                flex-wrap: wrap;
            }
            
            .share-btn {
                padding: 0.5rem 1rem;
                background-color: var(--color-white);
                border: 1px solid var(--color-border);
                font-size: 0.875rem;
                transition: all var(--transition-fast);
            }
            
            .share-btn:hover {
                background-color: var(--color-primary);
                color: var(--color-white);
                border-color: var(--color-primary);
            }
            
            @media (max-width: 768px) {
                .story-modal {
                    padding: 0;
                }
                
                .story-modal-content {
                    max-height: 100vh;
                    border-radius: 0;
                }
                
                .story-modal-header,
                .story-modal-body,
                .story-modal-footer {
                    padding-left: 1.5rem;
                    padding-right: 1.5rem;
                }
            }
        `;
        document.head.appendChild(styles);
    }
}

// ========================================
// Close Story Modal
// ========================================
function closeStoryModal() {
    const modal = document.querySelector('.story-modal');
    if (modal) {
        modal.remove();
        document.body.style.overflow = '';
    }
}

// ========================================
// Scroll Animations
// ========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe timeline items
    document.querySelectorAll('.timeline-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Observe journal cards
    document.querySelectorAll('.journal-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// ========================================
// Mobile Menu
// ========================================
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-menu-close');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
}
