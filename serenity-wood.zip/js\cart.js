// ========================================
// SERENITY WOOD - Shopping Cart
// ========================================

class ShoppingCart {
    constructor() {
        this.items = JSON.parse(localStorage.getItem('cart')) || [];
        this.init();
    }

    init() {
        this.updateCartUI();
        this.bindEvents();
    }

    bindEvents() {
        // Cart toggle
        document.querySelectorAll('.cart-btn').forEach(btn => {
            btn.addEventListener('click', () => this.openCart());
        });

        // Close cart
        document.querySelectorAll('.cart-close').forEach(btn => {
            btn.addEventListener('click', () => this.closeCart());
        });

        // Overlay click
        document.getElementById('cart-overlay')?.addEventListener('click', () => {
            this.closeCart();
        });
    }

    addItem(product, quantity = 1) {
        const existingItem = this.items.find(item => item.id === product.id);

        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: quantity
            });
        }

        this.saveCart();
        this.updateCartUI();
        this.openCart();
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartUI();
    }

    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.id === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeItem(productId);
            } else {
                item.quantity = quantity;
                this.saveCart();
                this.updateCartUI();
            }
        }
    }

    getTotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getItemCount() {
        return this.items.reduce((count, item) => count + item.quantity, 0);
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.items));
    }

    updateCartUI() {
        // Update cart count badge
        document.querySelectorAll('.cart-count').forEach(badge => {
            badge.textContent = this.getItemCount();
        });

        // Update cart items
        const cartItemsContainer = document.getElementById('cart-items');
        if (cartItemsContainer) {
            if (this.items.length === 0) {
                cartItemsContainer.innerHTML = '<p class="cart-empty">Your cart is empty</p>';
            } else {
                cartItemsContainer.innerHTML = this.items.map(item => `
                    <div class="cart-item" data-id="${item.id}">
                        <div class="cart-item-image"></div>
                        <div class="cart-item-details">
                            <h4>${item.name}</h4>
                            <p>Qty: ${item.quantity}</p>
                            <p class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</p>
                        </div>
                        <button class="cart-item-remove" onclick="cart.removeItem(${item.id})">Remove</button>
                    </div>
                `).join('');
            }
        }

        // Update subtotal
        const subtotalElement = document.getElementById('cart-subtotal');
        if (subtotalElement) {
            subtotalElement.textContent = `$${this.getTotal().toFixed(2)}`;
        }
    }

    openCart() {
        document.getElementById('cart-sidebar')?.classList.add('active');
        document.getElementById('cart-overlay')?.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeCart() {
        document.getElementById('cart-sidebar')?.classList.remove('active');
        document.getElementById('cart-overlay')?.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Initialize cart
const cart = new ShoppingCart();
