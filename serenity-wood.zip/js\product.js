// ========================================
// SERENITY WOOD - Product Detail JavaScript
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
    loadProductDetail();
});

// ========================================
// Load Product Detail
// ========================================
function loadProductDetail() {
    if (typeof products === 'undefined') return;
    
    // Get product ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id'));
    
    if (!productId) {
        showProductNotFound();
        return;
    }
    
    const product = products.find(p => p.id === productId);
    
    if (!product) {
        showProductNotFound();
        return;
    }
    
    // Update breadcrumb
    document.getElementById('breadcrumb-product').textContent = product.name;
    document.title = `${product.name} | Serenity Wood`;
    
    // Render product detail
    renderProductDetail(product);
    
    // Load related products
    loadRelatedProducts(product);
}

// ========================================
// Render Product Detail
// ========================================
function renderProductDetail(product) {
    const container = document.getElementById('product-detail');
    if (!container) return;
    
    const categoryLabel = getCategoryLabel(product.category);
    
    container.innerHTML = `
        <div class="product-gallery">
            <div class="gallery-thumbs">
                <div class="gallery-thumb active">View 1</div>
                <div class="gallery-thumb">View 2</div>
                <div class="gallery-thumb">View 3</div>
            </div>
            <div class="main-image">
                <div class="main-image-placeholder">${product.name}</div>
            </div>
        </div>
        
        <div class="product-info-detail">
            <span class="section-label">${categoryLabel}</span>
            <h1>${product.name}</h1>
            <p class="product-price-detail">
                ${product.originalPrice ? `<span class="original">$${product.originalPrice.toFixed(2)}</span>` : ''}
                $${product.price.toFixed(2)}
            </p>
            
            <div class="product-description">
                <p>${product.description}</p>
            </div>
            
            <div class="product-meta">
                ${product.scentProfile ? `
                    <div class="product-meta-item">
                        <span class="product-meta-label">Scent Profile:</span>
                        <span class="product-meta-value">${product.scentProfile}</span>
                    </div>
                ` : ''}
                ${product.burnTime ? `
                    <div class="product-meta-item">
                        <span class="product-meta-label">Burn Time:</span>
                        <span class="product-meta-value">${product.burnTime}</span>
                    </div>
                ` : ''}
                <div class="product-meta-item">
                    <span class="product-meta-label">Origin:</span>
                    <span class="product-meta-value">${product.origin}</span>
                </div>
            </div>
            
            <div class="quantity-selector">
                <span class="quantity-label">Quantity:</span>
                <div class="quantity-control">
                    <button class="quantity-btn" onclick="updateQuantity(-1)">−</button>
                    <input type="number" class="quantity-input" id="quantity" value="1" min="1" max="10">
                    <button class="quantity-btn" onclick="updateQuantity(1)">+</button>
                </div>
            </div>
            
            <button class="btn btn-primary add-to-cart-btn" onclick="addProductToCart(${product.id})">
                Add to Cart - $${product.price.toFixed(2)}
            </button>
            
            <div class="product-trust">
                <div class="trust-item">
                    <span>🚚</span>
                    <span>Free shipping over $100</span>
                </div>
                <div class="trust-item">
                    <span>↩️</span>
                    <span>30-day returns</span>
                </div>
                <div class="trust-item">
                    <span>✓</span>
                    <span>Lab certified authentic</span>
                </div>
                <div class="trust-item">
                    <span>🌱</span>
                    <span>Sustainably sourced</span>
                </div>
            </div>
        </div>
    `;
    
    // Bind gallery thumb clicks
    document.querySelectorAll('.gallery-thumb').forEach(thumb => {
        thumb.addEventListener('click', function() {
            document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// ========================================
// Update Quantity
// ========================================
function updateQuantity(change) {
    const input = document.getElementById('quantity');
    if (!input) return;
    
    let newValue = parseInt(input.value) + change;
    if (newValue < 1) newValue = 1;
    if (newValue > 10) newValue = 10;
    
    input.value = newValue;
}

// ========================================
// Add Product to Cart
// ========================================
function addProductToCart(productId) {
    if (typeof products === 'undefined' || typeof cart === 'undefined') return;
    
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const quantityInput = document.getElementById('quantity');
    const quantity = quantityInput ? parseInt(quantityInput.value) : 1;
    
    cart.addItem(product, quantity);
}

// ========================================
// Load Related Products
// ========================================
function loadRelatedProducts(currentProduct) {
    const container = document.getElementById('related-products');
    if (!container || typeof products === 'undefined') return;
    
    // Get products in same category, excluding current
    const relatedProducts = products
        .filter(p => p.category === currentProduct.category && p.id !== currentProduct.id)
        .slice(0, 4);
    
    // If not enough, add random products
    if (relatedProducts.length < 4) {
        const otherProducts = products
            .filter(p => p.id !== currentProduct.id && !relatedProducts.includes(p))
            .slice(0, 4 - relatedProducts.length);
        relatedProducts.push(...otherProducts);
    }
    
    container.innerHTML = relatedProducts.map(product => `
        <div class="product-card">
            <a href="product.html?id=${product.id}" class="product-link">
                <div class="product-image">
                    <div class="product-placeholder">${product.name}</div>
                    ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
                </div>
            </a>
            <div class="product-info">
                <a href="product.html?id=${product.id}">
                    <h3>${product.name}</h3>
                </a>
                <p class="product-price">
                    ${product.originalPrice ? `<span class="original">$${product.originalPrice.toFixed(2)}</span>` : ''}
                    $${product.price.toFixed(2)}
                </p>
            </div>
        </div>
    `).join('');
}

// ========================================
// Show Product Not Found
// ========================================
function showProductNotFound() {
    const container = document.getElementById('product-detail');
    if (container) {
        container.innerHTML = `
            <div style="text-align: center; padding: 4rem 0; grid-column: 1 / -1;">
                <h2>Product Not Found</h2>
                <p style="color: var(--color-text-light); margin: 1rem 0 2rem;">
                    Sorry, we couldn't find the product you're looking for.
                </p>
                <a href="shop.html" class="btn btn-primary">Browse All Products</a>
            </div>
        `;
    }
}

// ========================================
// Get Category Label
// ========================================
function getCategoryLabel(category) {
    const labels = {
        'meditation': 'MEDITATION COLLECTION',
        'sleep': 'SLEEP & RELAXATION',
        'home': 'HOME SANCTUARY',
        'gift': 'GIFTING'
    };
    return labels[category] || 'COLLECTION';
}

// ========================================
// Mobile Menu
// ========================================
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeBtn = document.querySelector('.mobile-menu-close');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
}
